# Andrew Song - 1204822
# Assignment 1 - readme.txt
# CIS4010
# 01/30/23

Please note that I developed on a newer version of python3 (3.10.6) than what is currently installed on the school servers. If 
you run into trouble running the program, please use a newer version of python. Thank you.

Before running the shell, ensure you have a S5-S3.conf file in the same directory, containing your own credentials.
Set the default region to ca-central-1

To install the required dependencies and packages, use the command "pip install -r requirements.txt"

To run the shell, use the command "./aws-shell.py"

The shell should perform according to the assignment specifications.

* I have been granted an extension until 01/30/23 by the professor, so please do not mark my assignment late. Thank you!
